# Requirements (Win8+/MacOS/Linux/ARM)

- [.NET 8.0 SDK or higher](https://dotnet.microsoft.com/download)*

* Be sure to install the **32- and 64-bit version on windows**! Both are absolutely necessary!

# Legal

Violation of any of the terms below will result in the termination of your Account. You agree to use the Service at your own risk.

# License
Attribution-NonCommercial-NoDerivs 4.0 Unported <http://creativecommons.org/licenses/by-nc-nd/4.0/>