<p align="center">
  <a href="https://discord.gg/8FMzSRJ">
    <img src="https://discordapp.com/api/guilds/365129052832530433/widget.png?style=banner2" />
  </a>
</p>

# Requirements (Windows-/MacOS-/Linux)

- [.NET 7.0 SDK or higher](https://dotnet.microsoft.com/download)*

# Legal

Violation of any of the terms below will result in the termination of your Account. You agree to use the Service at your own risk.

# License
Attribution-NonCommercial-NoDerivs 4.0 Unported <http://creativecommons.org/licenses/by-nc-nd/4.0/>